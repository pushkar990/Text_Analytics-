Hurricane Mitch, category 5 hurricane, brought widespread death and destruction to Central American.
Especially hard hit was Honduras where an estimated 6,076 people lost their lives.
The hurricane, which lingered off the coast of Honduras for 3 days before moving off, flooded large areas, destroying crops and property.
The U.S. and European Union were joined by Pope John Paul II in a call for money and workers to help the stricken area.
President Clinton sent Tipper Gore, wife of Vice President Gore to the area to deliver much needed supplies to the area, demonstrating U.S. commitment to the recovery of the region.

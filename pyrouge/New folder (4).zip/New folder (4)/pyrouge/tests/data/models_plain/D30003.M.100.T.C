Former Chilean dictator Augusto Pinochet has been arrested in London at the request of the Spanish government.
Pinochet, in London for back surgery, was arrested in his hospital room.
Spain is seeking extradition of Pinochet from London to Spain to face charges of murder in the deaths of Spanish citizens in Chile under Pinochet's rule in the 1970s and 80s.
The arrest raised confusion in the international community as the legality of the move is debated.
Pinochet supporters say that Pinochet's arrest is illegal, claiming he has diplomatic immunity.
The final outcome of the extradition request lies with the Spanish courts.
